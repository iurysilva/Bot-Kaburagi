from objetos.kaburagi import Kaburagi

